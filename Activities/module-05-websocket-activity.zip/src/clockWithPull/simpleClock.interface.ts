export default interface ISimpleClock {

    /** sets the time to 0 */
    reset():void

    /** increments the time */ 
    tick():void

    /** returns the current time */
    getTime():number
}
