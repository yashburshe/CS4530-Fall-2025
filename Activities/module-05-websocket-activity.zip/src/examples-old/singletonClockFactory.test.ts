import SingletonClockFactory from './SingletonClockFactory'


test("test of the Clock produced by SingletonClockFactory", () => {
    const clock1 = SingletonClockFactory.instance()
    expect(clock1.getTime()).toBe(0)
    clock1.tick()
    clock1.tick()   
    expect(clock1.getTime()).toBe(2)
    clock1.reset()
    expect(clock1.getTime()).toBe(0)
})

test("actions on clock1 should be visible on clock2", () => {
    const clock1 = SingletonClockFactory.instance()
    const clock2 = SingletonClockFactory.instance()
    expect(clock1.getTime()).toBe(0)
    expect(clock2.getTime()).toBe(0)
    clock1.tick()
    clock1.tick()   
    expect(clock1.getTime()).toBe(2)
    expect(clock2.getTime()).toBe(2)
    clock1.reset()
    expect(clock1.getTime()).toBe(0)
    expect(clock2.getTime()).toBe(0)

})

