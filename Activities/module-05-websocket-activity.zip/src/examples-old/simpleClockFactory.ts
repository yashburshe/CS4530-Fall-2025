import { SimpleClock } from '../clockWithPull/simpleClock';
import IClock from "../clockWithPull/simpleClock.interface";

export class SimpleClockFactory {
    public static createClock () : IClock {
        return new SimpleClock()
    }
}