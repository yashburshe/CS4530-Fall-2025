import IClock from "../clockWithPull/simpleClock.interface";
import { SimpleClockFactory } from "./simpleClockFactory";

function testClock(clock: IClock, clockName: string) {
    clock.reset()
    clock.tick()
    expect(clock.getTime()).toBe(1)
    clock.tick()
    expect(clock.getTime()).toBe(2)
    clock.reset()
    expect(clock.getTime()).toBe(0)
}

describe('the clock factory should build some working clocks', () => {

    it('works', () => {
        const clock1 = SimpleClockFactory.createClock()
        testClock(clock1, 'clock1')
        const clock2 = SimpleClockFactory.createClock()
        testClock(clock2, 'clock2')
    })
})