## Overview

In this activity, you will experiment with asynchronous programming constructs in TypeScript.

### Getting started

Run `npm install` to download the dependencies for this project, and then open it in your IDE of
choice. Run `npm run examples` to run the examples as-is
