This folder is for files you don't want tsc to look at.
(See tsconfig.json to see how this is done)