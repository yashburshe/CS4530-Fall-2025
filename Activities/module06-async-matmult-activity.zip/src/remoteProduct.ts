// remoteProduct.ts

/**
 * Calls a remote service to compute the product of two numbers.
 *
 * Note: We use a local Express server instead of the mathjs.org API because
 * mathjs.org has a 1 million daily request limit that gets exceeded when all
 * students run this activity simultaneously. The local server preserves the
 * async/await learning objectives with an artificial 50ms network delay.
 *
 * @param {number} a - The first number.
 * @param {number} b - The second number.
 * @returns {Promise<number>} - The product returned by the server.
 */
export default async function remoteProduct(a: number, b: number, noisy=false): Promise<number> {
  const url = `http://localhost:3001/multiply?a=${a}&b=${b}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Failed to fetch product: ${response.statusText}`);
  }

  const text = await response.text();
  const result = Number(text);

  if (Number.isNaN(result)) {
    throw new Error('Server did not return a valid number');
  }

  if (noisy) {
    // eslint-disable-next-line no-console
    console.log(`${a} * ${b} = ${result}`);
  }

  return result;
}