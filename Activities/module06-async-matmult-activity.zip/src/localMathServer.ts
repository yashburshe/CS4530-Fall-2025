// localMathServer.ts
// Local Express server to replace the mathjs.org API when it's rate-limited
// Run with: npx ts-node src/localMathServer.ts

import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 3001;

// Simulated network delay in milliseconds
// Adjust this to see different performance characteristics
const NETWORK_DELAY_MS = 50;

app.use(cors());

// Endpoint to multiply two numbers
// Example: http://localhost:3001/multiply?a=5&b=3
app.get('/multiply', async (req, res) => {
  const a = parseFloat(req.query.a as string);
  const b = parseFloat(req.query.b as string);

  if (Number.isNaN(a) || Number.isNaN(b)) {
    return res.status(400).send('Invalid parameters');
  }

  // Simulate network delay to preserve the async performance lesson
  await new Promise(resolve => setTimeout(resolve, NETWORK_DELAY_MS));

  const result = a * b;
  return res.send(result.toString());
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Local math server running on http://localhost:${PORT}`);
  // eslint-disable-next-line no-console
  console.log(`Network delay set to ${NETWORK_DELAY_MS}ms per request`);
});