#  Matrix Multiplication and Asynchronous Programming

This repository contains code and activities for learning about matrix multiplication and asynchronous programming in JavaScript/TypeScript. It includes implementations of matrix multiplication algorithms, performance comparisons, and examples of asynchronous programming techniques.

## File Descriptions

`matrices.ts` defines types and functions for creating and manipulating matrices.

`testAll.test.ts` contains tests for the matrix multiplication functions. It is parameterized to run the same tests on different implementations of matrix multiplication.

`timeComparison.ts` contains code to compare the performance of different asynchronous programming techniques, specifically serial and concurrent execution of asynchronous tasks. It includes functions to measure execution time and report statistics.
