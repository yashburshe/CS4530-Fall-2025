## Activity: User Stories and Conditions of Satisfaction Using Value Sensitive Design

### Introduction

This activity will give you practice with requirements analysis using an ethical framework 
such as value sensitive design. Additonally,
you will document the requirements gathered during the analysis using user stories with
conditions of satisfaction. 

Before you start, be sure to review the Reddit case study discussed in the lecture slides and the tutorial "User Stories and Conditions of Satisfaction" on the course website.

### Scenario

During dicussion on the Reddit case study, we came
up with two potential high-level reqirements after 
performing empirical, value, and technical investigations as part of the VSD process:

1. The flagging feature gives an explanation to the user as to why the system flagged and removed their content. If, after reading the explanation, the user thought the flagging was in error, they can submit the flag for further review. 

2. The system prompts the user to reconsider (does not prevent) if their post is potentially offensive.


### Requirements for this activity

1. Choose one of the two high-level requirements using the VSD process. Briefly explain your reasoning. In your explanation be sure to identify at least 3 stakeholders (e.g., consumer) and 3 values (e.g., informed consent).
   
2. Define a user story for each stakeholder.  These should be of the form
   
    As a <code>&lt;stakeholder&gt;</code> I want <code>&lt;some capability&gt;</code> so that I can <code>&lt;get some benefit&gt;</code>

3. For **each** user story, write 3 conditions of satisfaction with appropriate priorities. (Essential = user story is not satisfied without it)

Please submit a total of:

* 1 high-level requirement with your analysis
* 3 user stories
* 9 conditions of satisfaction with priorities

When you are done, submit your work as required by your instructor (check the Canvas asssignment for details, if assigned). This may vary from section to section.
