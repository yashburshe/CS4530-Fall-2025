// remoteProductLocal.ts
// Local version of remoteProduct that uses the local Express server instead of mathjs.org

/**
 * Calls a local server to compute the product of two numbers.
 * @param {number} a - The first number.
 * @param {number} b - The second number.
 * @returns {Promise<number>} - The product returned by the local server.
 */
export default async function remoteProduct(a: number, b: number, noisy=false): Promise<number> {
  // Use local server instead of mathjs.org
  const url = `http://localhost:3001/multiply?a=${a}&b=${b}`;

  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch product: ${response.statusText}`);
    }

    const text = await response.text();
    const result = Number(text);

    if (Number.isNaN(result)) {
      throw new Error('Server did not return a valid number');
    }

    if (noisy) {
      // eslint-disable-next-line no-console
      console.log(`${a} * ${b} = ${result}`);
    }

    return result;
  } catch (error) {
    // Check if local server is not running
    if ((error as any).code === 'ECONNREFUSED') {
      throw new Error('Local server not running! Start it with: npx ts-node src/localMathServer.ts');
    }
    throw error;
  }
}