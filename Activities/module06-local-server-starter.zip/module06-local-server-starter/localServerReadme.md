# Module 06 - Local Server Version

This version uses a local server instead of the mathjs.org API to avoid rate limiting issues.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Start the local server (keep this running):
```bash
npx ts-node src/localMathServer.ts
```

3. In a new terminal, switch to local version:
```bash
cp src/remoteProductLocal.ts src/remoteProduct.ts
```

4. Now work on the assignment as normal:
- Create `matrixMultiplyAsync2.ts`
- Create `matrixMultiplyAsync3.ts` (optional)
- Create `performanceTest.ts`
- Run tests: `npm test`

## What's Different?
- Added `localMathServer.ts` - Express server with 50ms delay
- Added `remoteProductLocal.ts` - Calls localhost instead of mathjs.org
- Added express and cors to package.json

## Expected Performance
With 10x10 matrices:
- matrixMultiplyAsync1: ~50 seconds
- matrixMultiplyAsync2: ~5 seconds
- matrixMultiplyAsync3: ~200ms