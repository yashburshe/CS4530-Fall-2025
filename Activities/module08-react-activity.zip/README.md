# React Activity - Module 08

This is a React project built with [Vite](https://vitejs.dev/) for fast development and building.

## Getting Started

First, install the dependencies:

```bash
npm install
```

Then, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing by modifying the React components in the `src/` directory. The page auto-updates as you edit the files thanks to Vite's hot module replacement.

This project uses:

- [Vite](https://vitejs.dev/) - Fast build tool and dev server
- [React 18](https://reactjs.org/) - UI library
- [TypeScript](https://www.typescriptlang.org/) - Type safety
- [Chakra UI](https://chakra-ui.com/) - Component library

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build for production
- `npm run preview` - Preview the production build locally
- `npm run lint` - Run ESLint

## Learn More

To learn more about the technologies used in this project:

- [Vite Documentation](https://vitejs.dev/guide/) - learn about Vite features and configuration
- [React Documentation](https://reactjs.org/docs/) - learn React concepts and API
- [TypeScript Documentation](https://www.typescriptlang.org/docs/) - learn TypeScript
- [Chakra UI Documentation](https://chakra-ui.com/docs/) - learn about the component library

