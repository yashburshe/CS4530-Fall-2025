# Test Adequacy Activity
In this activity, we will gain experience improving test suites using two adequacy criteria: line coverage and mutation coverage.

You are provided with a simple transcipt management system (TranscriptService). The starter implementation has some limitations and flaws, and you will improve the test suite, *not* the implementation.

(The instructions reference line numbers in transcriptService.ts. Do *not* change that file while you are following along, or else you may find that the line referenced do not match what you see.)

## First steps:
As usual, download the [starter code]({{ site.baseurl }}{% link Activities/module03-test-adequacy.zip %}) and run `npm install`.

After install, `npm test` executes the test suite:

```
$ npm test

> module03-test-adequacy@1.0.0 test
> jest --coverage

 PASS  src/transcriptService.test.ts
  TranscriptService
    Create student
      ✓ should return an ID, starting with 1 (1 ms)
    Adding grades
      ✓ should add the grade to the transcript (1 ms)
      ✓ Should throw an error if the student ID is invalid (4 ms)
    getStudentIDsByName
      ✓ Should return only the students who match the name (1 ms)
    Deleting students
      ✓ Should result in the students' transcript no longer being available (1 ms)
      ✓ Should throw an error if the ID is invalid
    getAll
      ✓ Should return the transcripts
    getGPA
      ✓ should compute GPA correctly for multiple courses (1 ms)
    isEnrolled
      ✓ should return true if the student is enrolled in the course

----------------------|---------|----------|---------|---------|-------------------
File                  | % Stmts | % Branch | % Funcs | % Lines | Uncovered Line #s 
----------------------|---------|----------|---------|---------|-------------------
All files             |   95.34 |       75 |     100 |   94.73 |                   
 transcriptService.ts |   95.34 |       75 |     100 |   94.73 | 91,110            
----------------------|---------|----------|---------|---------|-------------------
Test Suites: 1 passed, 1 total
Tests:       9 passed, 9 total
Snapshots:   0 total
Time:        0.459 s, estimated 1 s
Ran all test suites matching transcriptService.
```

This output shows the tests that ran, the percentage of statements/branches/functions/lined covered, and the lines not covered.

Examine the tests in the file `transcriptService.test.ts`, and the implementation in `transcriptService.ts`. 

## line Coverage

First examine the lines that are not covered in `transcriptService.ts`, and add new tests so that they are covered. Hence, your goal is to cover lines 91 and 110.  Put your new tests in a file `newTests.test.ts`

As you implement tests, think about how your tests reflect the principles of "good tests" that we discussed in class.

As an example, there is one "TODO" that points out what is likely a bad assumption of a starter test: the order of transcripts returned by `getStudentIDsByName` is always in the order the students were added. Do you think that this is a reasonable assumption? Is it worth the effort to change the test, or would you leave it as it is?

## Mutation Coverage

As you implemented your tests with line coverage in mind, you may have noticed that there are many different tests which would cover those lines and that some of those might have been stronger than others.

Mutation coverage helps us spot weak tests. Run `npm run stryker`. This should take no longer than a minute. You should see output ending with something like this:

```

[Survived] ArrayDeclaration
src/transcriptService.ts:9:41
-       private transcripts: Transcript[] = []
+       private transcripts: Transcript[] = ["Stryker was here"]
Ran all tests for this mutant.

Ran 4.42 tests per mutant on average.
----------------------|------------------|----------|-----------|------------|----------|----------|
                      | % Mutation score |          |           |            |          |          |
File                  |  total | covered | # killed | # timeout | # survived | # no cov | # errors |
----------------------|--------|---------|----------|-----------|------------|----------|----------|
All files             |  74.19 |   79.31 |       46 |         0 |         12 |        4 |        0 |
 transcriptService.ts |  74.19 |   79.31 |       46 |         0 |         12 |        4 |        0 |
----------------------|--------|---------|----------|-----------|------------|----------|----------|
00:14:56 (79544) INFO HtmlReporter Your report can be found at: file:///Users/vihar_gunamgari/Documents/Fall25/CS4530FSE-TA/module03-test-adequacy/reports/mutation/mutation.html
00:14:56 (79544) INFO MutationTestExecutor Done in 5 seconds.
```

Open the HTML report (in VSC open the file explorer, right click on mutation.html, and select "Open with Live Server"; or else copy/paste the URL into a browswer). Click on `transcriptService.ts` to see the report. Examine the mutants that are not detected. The first "survived" (not detected) mutant should be on line 9. Clicking on the red dot will reveal the mutation:
![Mutation report screenshot showing mutant on line 9 "ArrayDeclaration Survived"](mutantReport.png)

This report shows that Stryker changed line 9 to default the student's starting transcript to be an array with the single element `"Stryker was here"`. This mutation was not detected by the test suite: there is no test that will fail if the student transcript were initialized to be anything besides an empty array!

To enhance the test suite to detect this mutant, add a test that adds a new student to the `db`, and then expects that the student's transcript is empty.  Put your new tests in a file `newTests.test.ts`

After you add the new test, run `npm run stryker` again to get an updated mutation report, and reload it in your browser. You should now see that the mutation on the line is "killed" (show the "killed" mutants by clicking "killed" in the filter bar at the top).

Examine the remaining mutants that are not detected, and consider writing tests that will detect them. For each, think about how the mutated program behavior would differ, and how you could detect that difference. Remember that some mutations might be "equivalent"; that they do not cause any detectable behavioral difference. 

Some mutants might cause an observable difference in behavior, but if they are outside of a reasonable specification, they may not matter. For example, do you think that we should write tests that expect that each error message has some particular format?


## Requirements
Please write tests so that lines 91 and 110 are covered. Also, examine remaining mutants that are either survived or not detected and write tests that will detect & kill them. Put all your new tests in a file `newTests.test.ts`. When you are done, submit that file only.

Be sure to review the canvas assignment for submission and other related details (if assigned).