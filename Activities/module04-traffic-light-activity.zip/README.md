# Readable Code Activity

Run `npm install` to download the dependencies for this project, and then open it in VSC. 

Run `npm run test` to run the tests of the existing code (or run the script in VSC).  You will see that the tests pass.

Then modify the code as per the instructions in the Activity page.


