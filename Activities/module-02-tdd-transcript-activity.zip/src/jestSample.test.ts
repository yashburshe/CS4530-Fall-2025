// import { describe, test, expect } from 'vitest';
// like jest, but blindingly fast and with better error messages

const alvin = {studentID: 37, studentName: "Alvin"}
const bryn = {studentID: 38, studentName: "Bronwyn"}

describe("simple Jest examples", () => {

    test("extracting a studentID should give the ID", () => {
        expect(alvin.studentID).toEqual(37)
        expect(bryn.studentID).toEqual(38)
    })

    // remove the .not to illustrate what Jest shows when a test fails
    test("extracting a studentID should give the name", () => {
        expect(alvin.studentName).toEqual("Alvin")
        expect(bryn.studentName).not.toEqual("Jazzhands")
    })

})
