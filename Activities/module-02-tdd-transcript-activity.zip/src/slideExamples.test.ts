import TranscriptService from "./transcriptService";

const db = new TranscriptService();


// start each test with a fresh empty database.
beforeEach(() => {
  // Before any test runs, clean up the datastore. This should ensure that tests are hermetic.
  db.initialize([]);
});

// illustrative tests for lecture slides
describe('tests for addStudent', () => {

  test('addStudent should add a student to the database', () => {
    expect(db.getStudentIDsByName('blair')).toEqual([])
    const id1 = db.addStudent('blair');
    expect(db.getStudentIDsByName('blair')).toEqual([id1])
  });

  test('addStudent should return an unique ID for the new student',
    () => {
      // we'll just add 3 students and check to see that their IDs
      // are all different.
      const id1 = db.addStudent('blair');
      const id2 = db.addStudent('corey');
      const id3 = db.addStudent('delta');
      expect(id1).not.toEqual(id2)
      expect(id1).not.toEqual(id3)
      expect(id2).not.toEqual(id3)
    });

  test('the db can have more than one student with the same name',
    () => {
      const id1 = db.addStudent('blair');
      const id2 = db.addStudent('blair');
      expect(id1).not.toEqual(id2)
    })

  test('A newly-added student should have an empty transcript',
    () => {
      const id1 = db.addStudent('blair');
      const retrievedTranscript = db.getTranscript(id1, 'blair');
      expect(retrievedTranscript).toBeDefined()
      expect(retrievedTranscript.studentID).toEqual(id1)
      expect(retrievedTranscript.studentName).toEqual('blair')
      expect(retrievedTranscript.courses).toEqual([])
    });

  test('getTranscript should return the right transcript',
    () => {
      // add a student, getting an ID
      // add some grades for that student
      // retrieve the transcript for that ID
      // check to see that the retrieved grades are 
      // exactly the ones you added.    
    });

    test('getTranscript should return the right transcript',
      () => {
        // add a student, getting an ID
        const studentName = 'blair';
        const id1 = db.addStudent(studentName);
        db.addGrade(id1, studentName, 'cs101', 100);
        db.addGrade(id1, studentName, 'cs102', 50);
        db.addGrade(id1, studentName, 'cs102', 90);        
        const retrievedTranscript = db.getTranscript(id1, 'blair');
        expect(retrievedTranscript).toBeDefined();
        expect(retrievedTranscript.studentID).toEqual(id1);
        expect(retrievedTranscript.studentName).toEqual('blair');
        expect(retrievedTranscript.courses).toEqual([
          { courseID: 'cs101', grade: 100 },
          { courseID: 'cs102', grade: 50 },
          { courseID: 'cs102', grade: 90 }
        ]); 
      });

  test('getTranscript should throw an error when given a bad ID',
    () => {
      // in an empty database, all IDs are bad :)
      // Note: the expression you expect to throw must be wrapped in a (() => ...)
      const badQuery = () => db.getTranscript(-1, 'test student')
      expect(badQuery).toThrow()
    });


})


