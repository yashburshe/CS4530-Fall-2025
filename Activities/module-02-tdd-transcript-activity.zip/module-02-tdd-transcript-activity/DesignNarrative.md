Our next step is to turn these satisfaction conditions into testable behaviors

But to do this, we needed to go back to the client and clarify how these behaviors are to be delivered.

After some negotiation, we've agreed that they are to be delivered as a class with methods that provide the specified behaviors.

In the jargon of web applications, this is called a "Service Layer".  (show the 3-layer figure here)
The service layer is an abstraction of everything below it, so for the purposes of writing tests, we don't need to worry about the repository layer.
​
.... here say something about databases, and we learned back in our DB course that our records will be a database, so we'll need a primary key (which we'll call the StudentID), and we've agreed with the client:

​1. That the student ID will be a positive integer
2. That identifying a request with just the studentID is too error prone, so we'll label all requests with a studentID and a student name (which will be a string).
3. The service should deal with illegal requests by throwing an error.

[Note that these steps involve negotiation with the client, which is something we want to encourage]

In our discussions with the client, we started talking about the list of courses and grades.  Here are some of the issues that came up, and how they were resolved:

1. Can a student take a course more than once? (no)
2. Must the grades on the transcript be listed in the same order that the course was taken (ie, the order that the grade was added) (Yes)
3. Do we care about misspelled course names? (no)

We also talked with the client about their non-functional requirements, and agreed on the following:

1. Our database need only handle a couple of hundred students, and need only give prompt responses for databases of that size.
2. Access to the client's machine is already secured, so security or authentication is not a required feature of our deliverable.

(If this were a real project, these would be very important, of course, but we are keeping the project small!)


