import mongoose from 'mongoose';
import connectDatabase from './database/connect';
import createDatabase from './database/create';
import runFindQueryExamples from './database/find-queries';
import runPopulateQueryExamples from './database/populate-queries';

async function main() {
  // Check for command line argument (flag for pausing after each query)
  // The '--pause' flag allows you to pause after each query to review the results
  // before moving to the next one.
  const pauseAfterEachQuery = process.argv.includes('--pause');

  // Establish a connection to the MongoDB database
  await connectDatabase();

  // Create necessary collections and set up the database schema
  await createDatabase();

  // Executes find queries
  await runFindQueryExamples(pauseAfterEachQuery);
  // Executes populate queries
  await runPopulateQueryExamples(pauseAfterEachQuery);

  // Disconnect from the MongoDB database once all queries are complete
  await mongoose.disconnect();

  // Print a completion message after the tutorial is finished
  console.log('Completed tutorial!');
}

// Call the main function to start the tutorial
main();
