import mongoose, { Model, Schema } from 'mongoose';
import { Vet } from '../types';

/** Schema and model for Vet */
const vetSchema = new Schema({
  name: { type: String, required: true },
  age: { type: Number, required: true },
  clinic: { type: Schema.Types.ObjectId, ref: 'Clinic', required: true },
});

const VetModel: Model<Vet> = mongoose.model<Vet>('Vet', vetSchema);

export default VetModel;
