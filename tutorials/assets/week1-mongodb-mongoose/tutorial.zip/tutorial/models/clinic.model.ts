import mongoose, { Model, Schema } from 'mongoose';
import { Clinic } from '../types';

/** Schema and model for Clinic */
const clinicSchema = new Schema({
  name: { type: String, required: true },
  city: { type: String, required: true },
  phone: { type: String },
});

const ClinicModel: Model<Clinic> = mongoose.model<Clinic>('Clinic', clinicSchema);

export default ClinicModel;
