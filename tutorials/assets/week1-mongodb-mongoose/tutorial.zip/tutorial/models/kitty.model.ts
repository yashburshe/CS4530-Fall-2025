import mongoose, { Model, Schema } from 'mongoose';
import { Kitty } from '../types';

/** Schema and model for Kitty */
const kittySchema = new Schema({
  name: { type: String, required: true },
  color: { type: String, required: true },
  favoriteToy: { type: String, default: 'None' },
  vet: { type: Schema.Types.ObjectId, ref: 'Vet' },
});

const KittyModel: Model<Kitty> = mongoose.model<Kitty>('Kitty', kittySchema);

export default KittyModel;
