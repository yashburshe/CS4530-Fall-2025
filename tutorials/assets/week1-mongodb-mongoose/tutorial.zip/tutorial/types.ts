import { Schema } from 'mongoose';

/**
 * Represents a Clinic.
 */
export interface Clinic {
  /** The unique ID of the Clinic. */
  _id: Schema.Types.ObjectId;

  /** The name of the Clinic. */
  name: string;

  /** The city where the Clinic is located. */
  city: string;

  /** The phone number of the Clinic (optional). */
  phone?: string;
}

/**
 * Represents a Vet.
 */
export interface Vet {
  /** The unique ID of the Vet (optional). */
  _id?: Schema.Types.ObjectId;

  /** The name of the Vet. */
  name: string;

  /** The age of the Vet. */
  age: number;

  /** The clinic of the Vet, either as an ObjectId or a Clinic object. */
  clinic: Clinic | Schema.Types.ObjectId;
}

/**
 * Represents a Kitty.
 */
export interface Kitty {
  /** The unique ID of the Kitty (optional). */
  _id?: Schema.Types.ObjectId;

  /** The name of the Kitty. */
  name: string;

  /** The color of the Kitty. */
  color: string;

  /** The favorite toy of the Kitty */
  favoriteToy: string;

  /** The vet of the Kitty, either as an ObjectId or a Vet object. */
  vet: Vet | Schema.Types.ObjectId;
}

// ANSI escape codes for colors
export const GREEN = '\x1b[32m';
export const YELLOW = '\x1b[33m';
export const RESET = '\x1b[0m';
