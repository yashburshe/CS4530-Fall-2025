# React App with Cypress Testing

This is a React app built with TypeScript, React Router and Material-UI. It includes multiple pages and Cypress tests for various functionalities.

## Project Setup

### Install dependencies:
```sh
npm install
```

---

## Running the App

### `npm start`
Runs the app in development mode.  
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

- The page will **reload** if you make edits.
- You will also see any **lint errors** in the console.

---

## Running Cypress Tests
Make sure that the app is running before running the cypress tests.

### 1. Open Cypress Test Runner:
```sh
npx cypress open
```
This opens the Cypress test runner, where you can manually select and run tests.

### 2️. Run all Cypress tests in headless mode:
```sh
npx cypress run
```
This runs all Cypress tests in the terminal without opening the UI.

---

## Project Features & Tests

- **Home Page (`/`)**
  - Includes a **counter component** (tested)
  - Navigation buttons to **About** and **Contact** pages (tested)

- **About Page (`/about`)**
  - Displays basic information (tested)
  - Includes a **"Go to Home"** button (tested)

- **Contact Page (`/contact`)**
  - Has a **contact form** (tested)
  - Validates input fields before submission (tested)
  - Shows error messages when necessary (tested)
  - Includes a **"Go to Home"** button (tested)

- **Cypress Tests**
  - Navigation Tests
  - Counter Tests
  - Contact Form Validation Tests
  - Error Message Tests

---



