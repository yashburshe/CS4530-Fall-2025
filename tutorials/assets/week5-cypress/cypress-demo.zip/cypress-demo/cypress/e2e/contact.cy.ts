describe("Contact Form Tests", () => {
    beforeEach(() => {
      cy.visit("http://localhost:3000/contact");
    });
  
    it("Submits the form successfully", () => {
      cy.get("#contact-name").type("John Doe");
      cy.get("#contact-message").type("This is a test message.");
      cy.get("#contact-submit").click();
  
      cy.get("#contact-confirmation").should("contain", "Thank you, John Doe! We received your message.");
    });
  
    it("Shows an error for empty name field", () => {
      cy.get("#contact-message").type("Hello, this is a test message.");
      cy.get("#contact-submit").click();
  
      cy.get("#contact-error").should("contain", "Name cannot be empty");
    });
  
    it("Navigates back to Home when the 'Go to Home' button is clicked", () => {
      cy.get("#go-to-home").click();
      cy.url().should("include", "/");  // This should navigate back to the home page
      cy.get("#home-title").should("contain", "Welcome to My React App");  // Ensure we are on the home page
    });
  });
  