describe("404 Page Test", () => {
    it("Displays 404 page for unknown routes", () => {
      cy.visit("http://localhost:3000/nonexistent");
      cy.get("#not-found-page").should("exist");
      cy.contains("Oops! Page Not Found");
    });
  
    it("Navigates back to home from 404 page", () => {
      cy.visit("http://localhost:3000/nonexistent");
      cy.get("#return-home").click();
      cy.url().should("eq", "http://localhost:3000/");
    });
  });
  