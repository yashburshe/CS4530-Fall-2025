describe("Navigation Tests", () => {
    beforeEach(() => {
      cy.visit("http://localhost:3000");
    });
  
    it("Navigates to About page", () => {
      // Navigate to About page and verify its presence
      cy.get("#navigate-about").click();
      cy.url().should("include", "/about");
      cy.get("#about-page").should("exist");
    });

    it("Navigates to Contact page", () => {
     // Navigate to Contact page and verify its presence
     cy.get("#navigate-contact").click();
     cy.url().should("include", "/contact");
     cy.get("#contact-page").should("exist");
  });
});
