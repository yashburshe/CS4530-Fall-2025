describe("Counter Component Tests", () => {
    beforeEach(() => {
      cy.visit("http://localhost:3000");
    });
  
    it("Increments and decrements the counter", () => {
      cy.get("#counter-value").should("contain", "Count: 0");
  
      cy.get("#counter-increment").click();
      cy.get("#counter-value").should("contain", "Count: 1");
  
      cy.get("#counter-decrement").click();
      cy.get("#counter-value").should("contain", "Count: 0");
    });
  
    it("Does not decrement below 0", () => {
      cy.get("#counter-value").should("contain", "Count: 0");
  
      cy.get("#counter-decrement").click(); // Decrement from 0
      cy.get("#counter-value").should("contain", "Count: 0"); // It should stay at 0
    });
  
    it("Resets the counter to 0", () => {
      cy.get("#counter-value").should("contain", "Count: 0");
  
      cy.get("#counter-increment").click(); // Increment to 1
      cy.get("#counter-value").should("contain", "Count: 1");
  
      cy.get("#counter-reset").click(); // Reset the counter
      cy.get("#counter-value").should("contain", "Count: 0");
    });
  
    it("Increments the counter multiple times", () => {
      cy.get("#counter-value").should("contain", "Count: 0");
  
      cy.get("#counter-increment").click();
      cy.get("#counter-value").should("contain", "Count: 1");
  
      cy.get("#counter-increment").click();
      cy.get("#counter-value").should("contain", "Count: 2");
  
      cy.get("#counter-increment").click();
      cy.get("#counter-value").should("contain", "Count: 3");
    });
  
    it("Ensures correct display after multiple increment and decrement actions", () => {
      cy.get("#counter-value").should("contain", "Count: 0");
  
      cy.get("#counter-increment").click(); // Count = 1
      cy.get("#counter-increment").click(); // Count = 2
      cy.get("#counter-decrement").click(); // Count = 1
      cy.get("#counter-decrement").click(); // Count = 0
      cy.get("#counter-decrement").click(); // Should stay at Count = 0
  
      cy.get("#counter-value").should("contain", "Count: 0");
    });
  });
  