import React from "react";
import { Container, Typography, Button } from "@mui/material";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

const About: React.FC = () => {
  return (
    <Container
      id="about-page"
      style={{
        textAlign: "center",
        marginTop: "50px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <Typography variant="h3" gutterBottom>
        About Us
      </Typography>
      <Typography variant="body1" paragraph>
        This is a sample React app demonstrating Cypress testing.
      </Typography>

      {/* Go to Home button */}
      <div style={{ marginTop: "20px" }}>
        <Button
          id="go-home"
          variant="contained"
          color="primary"
          component={Link}
          to="/"
          style={{ width: "180px" }}
        >
          Go to Home
        </Button>
      </div>
    </Container>
  );
};

export default About;
