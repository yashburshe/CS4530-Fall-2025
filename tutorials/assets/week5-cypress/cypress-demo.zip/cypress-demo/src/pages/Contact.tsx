import React, { useState } from "react";
import { TextField, Button, Container, Typography } from "@mui/material";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const Contact: React.FC = () => {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Name cannot be empty");
      return;
    }
    setSubmitted(true);
  };

  return (
    <Container maxWidth="sm" id="contact-page" style={{ marginTop: "50px" }}>
      <Typography variant="h4" id="contact-title" gutterBottom>
        Contact Us
      </Typography>
      {submitted ? (
        <motion.p
          id="contact-confirmation"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          Thank you, {name}! We received your message.
        </motion.p>
      ) : (
        <form onSubmit={handleSubmit}>
          <TextField
            id="contact-name"
            label="Your Name"
            fullWidth
            margin="normal"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            id="contact-message"
            label="Message"
            fullWidth
            multiline
            rows={4}
            margin="normal"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          {error && <Typography color="error" id="contact-error">{error}</Typography>}
          <Button type="submit" id="contact-submit" variant="contained" color="primary" style={{ marginTop: "10px" }}>
            Submit
          </Button>
        </form>
      )}
      {/* Go to Home Button */}
      <Link to="/">
        <Button
          id="go-to-home"
          variant="outlined"
          color="primary"
          style={{ marginTop: "20px" }}
        >
          Go to Home
        </Button>
      </Link>
    </Container>
  );
};

export default Contact;
