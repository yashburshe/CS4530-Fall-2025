import React from "react";
import { Container, Typography, Button } from "@mui/material";
import { Link } from "react-router-dom";  // Import Link from react-router-dom

const NotFound: React.FC = () => {
  return (
    <Container
      id="not-found-page"
      style={{
        textAlign: "center",
        marginTop: "100px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <Typography variant="h2" color="error">
        404
      </Typography>
      <Typography variant="h5" gutterBottom>
        Oops! Page Not Found
      </Typography>
      <Typography variant="body1" style={{ marginBottom: "20px" }}>
        The page you are looking for might have been removed or does not exist.
      </Typography>
      <Button
        id="return-home"
        component={Link}
        to="/"
        variant="contained"
        color="primary"
        style={{ width: "180px" }}
      >
        Return to Home
      </Button>
    </Container>
  );
};

export default NotFound;
