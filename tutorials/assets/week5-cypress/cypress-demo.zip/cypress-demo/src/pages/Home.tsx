import React from "react";
import { Link } from "react-router-dom";
import { Button, Typography, Container } from "@mui/material";
import { motion } from "framer-motion";
import Counter from "../components/Counter";

const Home: React.FC = () => (
  <Container
    id="home-page"
    style={{
      textAlign: "center",
      marginTop: "50px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
      <Typography variant="h3" id="home-title" gutterBottom style={{ marginBottom: "20px" }}>
        Welcome to My React App
      </Typography>

      <Counter />

      <nav style={{ marginTop: "20px" }}>
        <Button
          variant="contained"
          color="primary"
          id="navigate-about"
          component={Link}
          to="/about"
          style={{ marginRight: "10px", width: "160px" }}
        >
          About Us
        </Button>

        <Button
          variant="contained"
          color="secondary"
          id="navigate-contact"
          component={Link}
          to="/contact"
          style={{ width: "160px" }}
        >
          Contact
        </Button>
      </nav>
    </motion.div>
  </Container>
);

export default Home;
