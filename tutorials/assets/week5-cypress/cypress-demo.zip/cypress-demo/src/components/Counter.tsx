import React, { useState } from "react";
import { Button, Typography } from "@mui/material";
import { motion } from "framer-motion";

const Counter: React.FC = () => {
    const [count, setCount] = useState(0);

    // Increment function
    const increment = () => setCount(count + 1);

    // Decrement function (prevents going below zero)
    const decrement = () => {
        if (count > 0) {
            setCount(count - 1);
        }
    };

    return (
        <div
            id="counter-component"
            style={{
                marginTop: "20px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
            }}
        >
            <Typography variant="h5" style={{ marginBottom: "10px" }}>
                Counter
            </Typography>
            <motion.p
                id="counter-value"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 0.2 }}
                style={{
                    fontSize: "2rem",
                    marginBottom: "20px",
                    fontWeight: "bold",
                }}
            >
                Count: {count}
            </motion.p>
            <div style={{ display: "flex", gap: "10px" }}>
                <Button
                    id="counter-reset"
                    variant="contained"
                    onClick={() => setCount(0)}
                    style={{ width: "120px" }}
                >
                    Reset
                </Button>
                <Button
                    variant="contained"
                    color="success"
                    id="counter-increment"
                    onClick={increment}
                    style={{ width: "120px" }}
                >
                    Increment
                </Button>
                <Button
                    variant="contained"
                    color="error"
                    id="counter-decrement"
                    onClick={decrement}
                    style={{ width: "120px" }}
                >
                    Decrement
                </Button>
            </div>
        </div>
    );
};

export default Counter;
