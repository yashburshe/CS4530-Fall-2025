
import { fakeRequest } from "./fakeRequest";

test('fakeRequest should return its argument + 10', async () => {
    expect.assertions(1)
    await expect(fakeRequest(33)).resolves.toEqual(43)
})

// this will succeed, because it does not await the promise
test('bogus test', async () => {
    // expect.assertions(1)
    expect(fakeRequest(33)).resolves.toEqual(99)
})

test('bogus test 2', () => {
    // expect.assertions(1)
    expect(fakeRequest(33)).resolves.toEqual(99)
})

test('fakeRequest should return its argument + 10', async () => {
    expect.assertions(3)
    await expect(fakeRequest(33)).resolves.toEqual(43)
})