import { waitRandom } from "../utils/fakeRequest";

/* run-to-completion semantics:

    JS uses "run-to-completion" semantics.  This means that once a computation starts, it runs continuously
    until it is either completed or suspended.

    A computation is suspended when it hits an 'await'.

    By contrast, Java uses interrupt-based semantics, in which control can 
    pass from one computation to another at any time.

    To see the difference, consider the example below:

*/ 



async function asyncPrintA() {
    await waitRandom(1);   // start an asynchronous computation and wait for the result
    console.log('A');
}

async function asyncPrintBC() {
    await waitRandom(2);     // start an asynchronous computation and wait for the result
    console.log('B');
    console.log('C');
}

async function run() {
    await Promise.all([asyncPrintA(), asyncPrintBC()])
}


run()


/**
 * In Java, the output could be any of the following:
 * 
 * ABC
 * BAC
 * BCA
 * 
 * In the run-to-completion semantics, *NOTHING* can happen between the 'B' and the 'C'.
 * So the output is always either:
 * 
 * ABC
 * BCA
 * 
 * The 'A' cannot appear between the 'B' and the 'C' because once the asyncPrintBC function starts
 * executing, it runs to completion until it finishes.
 */