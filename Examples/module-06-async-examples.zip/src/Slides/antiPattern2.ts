import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

async function f() {
    console.log('f started');
    await g();
    console.log('f done');
}

async function g() {
    console.log('g started');
    const res = await fakeRequest(32);
    console.log(`fakeRequest(32) returned: ${res}`);
    console.log('g done');
}

async function main() {
    console.log('main started');
    f();
    console.log('main done');
}

timeIt(main)

