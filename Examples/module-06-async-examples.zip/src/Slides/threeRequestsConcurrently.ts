import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

async function main() {
    console.log('starting main');
    const promises = [fakeRequest(1), fakeRequest(2), fakeRequest(3)];
    const results = await Promise.all(promises);
    console.log('results:', results);
    console.log('main done');
}

timeIt(main)

/** Summary:
 * 1. We can use Promise.all to run multiple promises concurrently.
 * 2. We can use await to wait for all promises to resolve.
 */

