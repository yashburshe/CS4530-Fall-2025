import axios from 'axios';

export async function makeRequest(requestNumber:number) {
    console.log(`starting makeRequest(${requestNumber})`);
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`request ${requestNumber} returned`);
}

function makeThreeConcurrentRequests() {
  console.log('starting make3ConcurrentRequests');
  makeRequest(100);
  makeRequest(200);
  makeRequest(300);
  console.log('make3ConcurrentRequests finished');
}

async function main() {
  makeThreeConcurrentRequests();
}

main()
