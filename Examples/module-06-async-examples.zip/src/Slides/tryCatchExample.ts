import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

// a request that may fail
async function maybeFailingRequest(req: number): Promise<number> {
    const res = await fakeRequest(req);
    if (res < 0) {
        console.log(`Request ${req} failing because response ${res} would be < 0`);
        throw new Error(`Request ${req} failed`);
    } else {
        return res;
    }
}


async function main() {
    console.log('main started');
    const req1 = -32
    let res: number;
    try {
        res = await maybeFailingRequest(req1);
        console.log(`fakeRequest(${req1}) returned: ${res}`);
    } catch (err) {
        console.error(`Recovering from failure with 0`);
        res = 0
    }    
    console.log('main done with res =', res);
}

timeIt(main);
