
async function someFunction(i: number) {
    const j = i + 1;
    // ... maybe do more calculations here ...
    const k = await someOtherAsyncFunction(j);
    // ... maybe do more calculations here ...
    const m = k + 100
    return m;
}

