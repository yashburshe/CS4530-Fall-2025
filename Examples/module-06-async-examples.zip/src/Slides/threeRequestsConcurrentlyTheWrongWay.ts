import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

async function main() {
    console.log('starting main');
    const res1 = fakeRequest(1);
    console.log(`fakeRequest(1) returned: ${res1}`);
    const res2 = fakeRequest(2);
    console.log(`fakeRequest(2) returned: ${res2}`);  
    const res3 = fakeRequest(3);
    console.log(`fakeRequest(3) returned: ${res3}`);     
}

timeIt(main)

/** Well, that didn't work!
 *  We didn't want to await the promises, because we wanted them to run concurrently. 
 *  But all fakePromise did was to return a promise.
 *  And the promises weren't executed until after the main function was done.
 *
 * 
 */

