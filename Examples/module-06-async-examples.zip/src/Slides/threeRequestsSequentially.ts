import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

async function main() {
    console.log('starting main');
    const res1 = await fakeRequest(1);
    console.log(`fakeRequest(1) returned: ${res1}`);
    const res2 = await fakeRequest(2);
    console.log(`fakeRequest(2) returned: ${res2}`);  
    const res3 = await fakeRequest(3);
    console.log(`fakeRequest(3) returned: ${res3}`);
    console.log('main done');     
}

timeIt(main)

