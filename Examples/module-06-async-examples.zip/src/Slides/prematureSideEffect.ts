import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";

async function main() {
    console.log('main started');
    const request = 32
    const res = fakeRequest(request);
    console.log(`fakeRequest(${request}) returned: ${res}`);
    console.log('main done');
}

async function f() {
    console.log('f started');
    await g();
    console.log('f done');
}

async function g() {
    console.log('g started');
    const res = await fakeRequest(32);
    console.log(`fakeRequest(32) returned: ${res}`);
}

timeIt(main)

/** fakeRequest just creates a promise and returns it.
 * 1. We are not awaiting the promise returned by fakeRequest.
 * 2. The promise not resolved until the current promise (main) is resolved.
 */

