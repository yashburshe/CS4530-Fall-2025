import { fakeRequest } from "../utils/fakeRequest";
import { timeIt } from "../utils/timeIt";


async function main() {
    console.log('main started');
    const request = 32
    const res = await fakeRequest(request);
    console.log(`fakeRequest(${request}) returned: ${res}`);
    console.log('main done');
}

timeIt(main)

