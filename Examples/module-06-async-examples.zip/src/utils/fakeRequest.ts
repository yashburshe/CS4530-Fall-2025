import axios from 'axios';

// export async function makeRequest(requestNumber:number) {
//     console.log(`starting makeRequest(${requestNumber})`);
//     const response = await axios.get('https://rest-example.covey.town');
//     console.log('request:', requestNumber, '\nresponse:', response.data);
// }

// returns a promise that waits for 1 second and then resolves with the number n+10
export function fakeRequest(n: number): Promise<number> {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('fakeRequest received request:',n);
            console.log('time passes....');
            resolve(n+10);
        }, 1000);
    });
}

export function waitRandom(n: number): Promise<number> {
    return new Promise((resolve, reject) => {
        const ms = 1000*Math.random();
        setTimeout(() => {
            console.log('waitRandom received request:',n);
            console.log(`${ms.toFixed(0)} msecs pass....`);
            resolve(n+10);
        }, ms);
    });
}





// promise that prints the string and returns void
function promiseToPrint(str: string): Promise<void> {
    return new Promise((resolve, reject) => {
        console.log(str);
        resolve();
    });
}


