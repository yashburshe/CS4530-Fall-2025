import { log } from "console"
import { ICallBackClient, ICallBackServer } from "./callBacks.interface"

export class Server implements ICallBackServer {

    // the log of all push messages received
    private _log: string[] = []

    // public handlePush(clientName: string): void {
    //     this._log.push(clientName)
    // }

    // using arrow function to bind 'this' correctly
    private pushHandler = (clientName: string) => () => { this._log.push(clientName) }
    private logHandler = (): string[] => { return this._log }

    public log(): string[] { return this._log }
    public newClient(clientName: string): ICallBackClient {
        return new Client(this.pushHandler(clientName), this.logHandler)
    }
}

export class Client implements ICallBackClient {

    // the client doesn't get to see the server directly; the server
    // creates it with two callbacks.

    constructor(
        _pushHandler: () => void,
        _logHandler: () => string[],
    ) { this.pushHandler = _pushHandler; this.logHandler = _logHandler;
    }

    private pushHandler: () => void
    private logHandler: () => string[]
    
    // the public methods just call the callbacks
    public sendPush() { this.pushHandler(); }
    public getLog(): string[] { return this.logHandler(); }

}


