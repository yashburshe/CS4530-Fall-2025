export interface ICallBackServer {

    // returns a new client that satisfies the ICallBackClient interface
    newClient(clientName: string): ICallBackClient;
    
    // returns the log of all push messages received
    log(): string[];
} 

export interface ICallBackClient {
     // sends a push message to the server, 
    sendPush: () => void
    // asks the server for list of all push messages received
    // from all clients.
    getLog: () => string[]; 

}


