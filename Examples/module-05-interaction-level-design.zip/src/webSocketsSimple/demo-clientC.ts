import createServer from "./server";
import Client from "./client";


// 
const client1 = new Client("C");  // client listens on server events

