import { IPushingClock, IPushingClockClient } from "./pushingClock.interface";

export class PushingClock implements IPushingClock {
    private time = 0

    reset() : void { this.time = 0; this.notifyAll() }
 
    tick() : void { this.time++; this.notifyAll() }     
    
    private observers: IPushingClockClient[] = []

    public addListener(obs:IPushingClockClient): number {
        this.observers.push(obs);
        return this.time
    }

    private notifyAll() : void {
            this.observers.forEach(obs => obs.notify(this.time))
        }
}

