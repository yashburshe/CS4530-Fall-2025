// System Under Test
import { nanoid  }from 'nanoid'
/** given a temperature in farenheit,
 * returns the corresponding temperature in celsius
 * */
function f2c(temperature: number): number {
  return (5 / 9) * (temperature - 32);
}

// Tests

describe('tests for f2c', () => {
  test('32 F => 0 C', () => {
    const n = nanoid()
    expect(f2c(32)).toBe(0);
  });
  test('212 F => 100 C', () => {
    expect(f2c(212)).toBe(100);
  });
});
