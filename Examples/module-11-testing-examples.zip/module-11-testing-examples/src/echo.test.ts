import { Echo } from './EchoClass';
import axios from 'axios';

async function mockAxiosCall(url: string) {
  return { data: { args: { answer: url.split('=')[1] } } }; 
 } 

// Hmm, we better test mockAxiosCall!
describe('tests for mockAxiosCall', () => {
  test('mockhttpbun should return its argument', async () => {
    const url = 'https://httpbun.com/get?answer=33'
    const res = await mockAxiosCall(url);
    expect(res).toEqual({ data: { args: { answer: "33" } } });
  });
})



describe('tests for echo', () => {
  beforeEach(jest.resetAllMocks);

  // this runs the http call.
  test('echo should return its argument', async () => {
    expect(await Echo.echo('33')).toEqual('33');
  });

  // this passes
  test('just spying on a function runs the original', async () => {
    const spy1 = jest.spyOn(axios, 'get');
    const str = '34';
    const res = await Echo.echo(str);
    expect(res).toEqual(str);
    expect(spy1).toBeCalledWith("https://httpbun.com/get?answer=34");
    expect(spy1).toBeCalledTimes(1);
  });

  // this one is obsolete
  test("mocking the http call doesn't actually do a live call", async () => {
    const spy1 = jest.spyOn(axios, 'get');

    // have the mock return this
    const mockAnswer = '777';
    const mockResponse = { data: { args: { answer: mockAnswer } } };
    spy1.mockResolvedValue(mockResponse); // don't run the original!

    const realInput = '43'; // put this in the URL
    const realQuery = `https://httpbun.com/get?answer=${realInput}`;

    // 'echo' takes the realInput, but returns the mockAnswer,
    // so the http call must not have taken place
    expect(await Echo.echo(realInput)).toEqual(mockAnswer);
    expect(spy1).toBeCalledWith(realQuery);
    expect(spy1).toBeCalledTimes(1);
  });

  test('mock axios.get so httpbun is not called', async () => {
    jest.resetAllMocks();
    const spy1 = jest.spyOn(axios, 'get').mockImplementation(mockAxiosCall);
    const str = '34';
    const res = await Echo.echo(str);
    expect(spy1).toHaveBeenCalled();
    expect(res).toEqual(str);
  })
});
