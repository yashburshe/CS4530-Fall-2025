import axios from 'axios';

export class Echo  {

  public static async echo(str: string): Promise<string> {
    const res = await axios.get(`https://httpbun.com/get?answer=${str}`);
    return res.data.args.answer;
  }

}


