import axios from 'axios';
/** a class with a static method `echo` that calls axios */
import { Echo } from './EchoClass';
// import * as Echo from './echoFn'

/** calls echo twice and concatenates the results */
import { echoClient } from './echoClient';

// I want to test echoClient, but I don't want to actually make the http call

// so: just mock echo with a correct return value
// and mock axios.get to always throw an error
describe('tests for echoClient', () => {
  beforeEach(jest.resetAllMocks);
  beforeEach(() => {
    // mock echo with a correct return value
    jest.spyOn(Echo, 'echo').mockImplementation((str: string) => Promise.resolve(str));
    // mock axios.get to always throw an error;
    // if our test calls the real axios.get, it will fail
    jest.spyOn(axios, 'get').mockRejectedValue('axios.get should not be called');
  })
  test('echoClient should return its argument twice', async () => {
    const str = '345';
    const res = await echoClient(str);
    expect(res).toEqual(str + str);
  });
})



 
