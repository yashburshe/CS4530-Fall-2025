import { mock, mockClear } from 'jest-mock-extended';
import { IClockListener, ProducerClock } from './clockWithObserverPattern';

const clock1 = new ProducerClock();
//Automatically create an implementation of IClockListener, each method is a mock function
const listener1 = mock<IClockListener>();
//Add the listener to the clock
clock1.addListener(listener1);

describe('tests for ProducerClock', () => {
    beforeEach(() => {
        //Clear the mock function's history
        mockClear(listener1);
    });
    test('after one tick, listener should return 1', () => {
        clock1.reset();
        clock1.tick();
        expect(listener1.notify).toHaveBeenLastCalledWith(1);
    });
    test('after two ticks, listener should return 2', () => {
        clock1.reset();
        clock1.tick();
        expect(listener1.notify).toHaveBeenLastCalledWith(1);
        clock1.tick();
        expect(listener1.notify).toHaveBeenLastCalledWith(2);
        expect(listener1.notify).toHaveBeenCalledTimes(2);
    });
});
