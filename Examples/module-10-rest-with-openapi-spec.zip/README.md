# Library Management REST API

A comprehensive REST API for managing a library system built with TypeScript, Express.js, and Swagger documentation.

## Features

- **Books Management**: CRUD operations for books with title, authors, genres, ISBN, and summary
- **Authors Management**: CRUD operations for authors with names, birth/death dates
- **Genres Management**: CRUD operations for book genres
- **Book Copies Management**: Track individual copies of books with status and due dates
- **In-Memory Storage**: No database required - all data stored in memory
- **OpenAPI Documentation**: Auto-generated API documentation with Swagger UI
- **Request/Response Validation**: Automatic validation using express-openapi-validator
- **TypeScript**: Full type safety and modern JavaScript features

## Data Models

### Book
- `id`: Unique identifier
- `title`: Book title
- `authorIds`: Array of author IDs (minimum 1)
- `genreIds`: Array of genre IDs (minimum 1)  
- `isbn`: ISBN number
- `summary`: Book description

### Author
- `id`: Unique identifier
- `firstName`: Author's first name (required)
- `lastName`: Author's last name (optional)
- `birthDate`: Birth date (required)
- `deathDate`: Death date (optional)

### Genre
- `id`: Unique identifier
- `name`: Genre name

### BookCopy
- `id`: Unique identifier
- `bookId`: Reference to book ID
- `imprint`: Publication imprint information
- `status`: One of: 'available', 'unavailable', 'can be checkout', 'checked out'
- `dueBackDate`: Due date for checked out books (optional)

## Installation

1. **Clone/Download the project files**

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Build the project:**
   ```bash
   npm run build
   ```

## Usage

### Development Mode
Start the server with auto-reload:
```bash
npm run dev
```

### Production Mode
Build and start the server:
```bash
npm run build
npm start
```

The server will start on port 3000 by default. You can change this by setting the `PORT` environment variable.

## API Documentation

Once the server is running, visit:
- **Swagger UI**: http://localhost:3000/api-docs
- **OpenAPI Spec**: The specification is automatically generated from JSDoc comments

## API Endpoints

### Authors
- `GET /authors` - Get all authors
- `GET /authors/{id}` - Get author by ID
- `POST /authors` - Create new author
- `PUT /authors/{id}` - Update author
- `DELETE /authors/{id}` - Delete author

### Genres
- `GET /genres` - Get all genres
- `GET /genres/{id}` - Get genre by ID
- `POST /genres` - Create new genre
- `PUT /genres/{id}` - Update genre
- `DELETE /genres/{id}` - Delete genre

### Books
- `GET /books` - Get all books
- `GET /books/{id}` - Get book by ID
- `POST /books` - Create new book
- `PUT /books/{id}` - Update book
- `DELETE /books/{id}` - Delete book

### Book Copies
- `GET /book-copies` - Get all book copies (supports filtering by bookId and status)
- `GET /book-copies/{id}` - Get book copy by ID
- `POST /book-copies` - Create new book copy
- `PUT /book-copies/{id}` - Update book copy
- `DELETE /book-copies/{id}` - Delete book copy

## Sample Data

The API comes pre-loaded with sample data:
- Authors: Isaac Asimov, Ursula K. Le Guin
- Genres: Science Fiction, Fantasy
- Books: Foundation by Isaac Asimov
- Book Copies: One copy of Foundation

## Example Requests

### Create a new author:
```bash
curl -X POST http://localhost:3000/authors \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Arthur",
    "lastName": "Clarke", 
    "birthDate": "1917-12-16",
    "deathDate": "2008-03-19"
  }'
```

### Create a new book:
```bash
curl -X POST http://localhost:3000/books \
  -H "Content-Type: application/json" \
  -d '{
    "title": "2001: A Space Odyssey",
    "authorIds": ["auth3"],
    "genreIds": ["gen1"],
    "isbn": "978-0-451-45739-4",
    "summary": "A science fiction novel about humanity's encounter with alien intelligence."
  }'
```

### Get books with filtering:
```bash
# Get all book copies for a specific book
curl "http://localhost:3000/book-copies?bookId=book1"

# Get all available book copies
curl "http://localhost:3000/book-copies?status=available"
```

## Project Structure

```
library-management-api/
├── src/
│   ├── app.ts                        # Main application file
│   ├── controllers/                  # Business logic controllers
│   │   ├── authorsController.ts      # Authors operations
│   │   ├── booksController.ts        # Books operations
│   │   ├── genresController.ts       # Genres operations
│   │   └── bookCopiesController.ts   # Book copies operations
│   ├── routes/                       # Express route definitions
│   │   ├── authors.ts                # Authors routes with Swagger docs
│   │   ├── books.ts                  # Books routes with Swagger docs
│   │   ├── genres.ts                 # Genres routes with Swagger docs
│   │   └── bookCopies.ts            # Book copies routes with Swagger docs
│   ├── models/                       # TypeScript interfaces
│   │   └── index.ts                  # Data model definitions
│   └── data/                         # Data layer
│       ├── storage.ts                # In-memory storage and utilities
│       └── sampleData.ts            # Sample data initialization
├── dist/                            # Compiled JavaScript (generated)
├── package.json                     # Dependencies and scripts
├── tsconfig.json                    # TypeScript configuration
└── README.md                       # This file
```

## Validation

The API uses express-openapi-validator to automatically validate:
- Request body schemas
- Path parameters
- Query parameters
- Required fields
- Data types and formats

Invalid requests will return appropriate 400 Bad Request responses with detailed error messages.

## Error Handling

The API provides consistent error responses:
- `400 Bad Request` - Invalid input data
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server errors

## Development

### Scripts Available:
- `npm run dev` - Start development server with auto-reload
- `npm run build` - Build TypeScript to JavaScript
- `npm start` - Start production server
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Fix ESLint issues automatically

### Adding New Endpoints:
1. **Define the route** in the appropriate file in `src/routes/`
2. **Add comprehensive JSDoc comments** with `@swagger` tags for documentation
3. **Create controller function** in the corresponding controller file
4. **Add any new interfaces** to `src/models/index.ts` if needed
5. **Update data storage functions** in `src/data/storage.ts` if needed
6. The OpenAPI documentation will be automatically generated

### Extending the System:
- **Adding a new resource**: Create new route, controller, and update models
- **Adding database support**: Replace the storage layer in `src/data/`
- **Adding authentication**: Add middleware in `src/app.ts`
- **Adding more validation**: Extend controller validation logic

## Technology Stack

- **Runtime**: Node.js
- **Language**: TypeScript
- **Framework**: Express.js
- **Architecture**: Modular MVC pattern with separate routes and controllers
- **Documentation**: Swagger JSDoc + Swagger UI Express
- **Validation**: Express OpenAPI Validator
- **Storage**: In-memory (no database required)

## Architecture

The application follows a modular, layered architecture:

### **Routes Layer** (`src/routes/`)
- Defines API endpoints and HTTP method handlers
- Contains Swagger/OpenAPI documentation
- Delegates business logic to controllers
- Each resource (authors, books, genres, book-copies) has its own route file

### **Controllers Layer** (`src/controllers/`)
- Contains business logic and validation
- Handles request/response processing
- Interacts with the data storage layer
- Separated by resource for better maintainability

### **Models Layer** (`src/models/`)
- TypeScript interfaces defining data structures
- Ensures type safety across the application
- Single source of truth for data schemas

### **Data Layer** (`src/data/`)
- In-memory storage implementation
- Utility functions for data operations (CRUD)
- Sample data initialization
- Abstracted to easily switch to a database later

## License

MIT License - feel free to use this project as a starting point for your own library management system!
